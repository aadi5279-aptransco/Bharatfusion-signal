import unittest,tempfile,threading
from unittest.mock import patch
import pandas as pd
import numpy as np
from engine import bars,analyze,demo_frame,clean,IST
from data import Cache,Dhan,DataError,parse_master
from kronos_adapter import prepare,Forecaster,ForecastError

class RulesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.f=demo_frame(7); cls.now=cls.f.index[-1].normalize()+pd.Timedelta(hours=14)
    def test_partial_candle_excluded(self):
        b=bars(self.f,3,self.now+pd.Timedelta(minutes=1))
        self.assertEqual(b.index[-1].minute,57)
    def test_gap_candle_excluded(self):
        f=self.f.drop(self.now-pd.Timedelta(minutes=2)); b=bars(f,3,self.now)
        self.assertNotIn(self.now-pd.Timedelta(minutes=3),b.index)
    def test_session_anchor(self):
        b=bars(self.f,60,self.now)
        self.assertTrue(all(t.minute==15 for t in b.index)); self.assertTrue(all(t.hour<=14 for t in b.index))
    def test_no_future_leakage(self):
        r=analyze(self.f,'X',now=self.now)
        later=self.f.copy(); later.loc[later.index>=self.now,['open','high','low','close']]*=4
        self.assertEqual(r,analyze(later,'X',now=self.now))
    def test_stale_blocks(self):
        r=analyze(self.f,'X',now=self.now+pd.Timedelta(days=4))
        self.assertEqual(r['action'],'WAIT'); self.assertIn('STALE candles',r['blockers'])
    def test_bad_ohlc_rejected(self):
        f=self.f.copy(); f.iloc[0,f.columns.get_loc('high')]=1
        with self.assertRaises(ValueError):clean(f)
    def test_index_no_volume_confirmation(self):
        f=self.f.copy(); f.volume=0
        r=analyze(f,'INDEX','index',now=self.now)
        self.assertNotIn('Volume confirmation absent',r['blockers']); self.assertIsNone(r['rvol'])
    def test_closed_weekend(self):
        now=pd.Timestamp('2026-10-25 12:00',tz=IST)
        r=analyze(self.f,'X',now=now)
        self.assertTrue(any('Outside entry window' in s for s in r['blockers']))
    def test_cache_roundtrip_and_journal_dedup(self):
        with tempfile.TemporaryDirectory() as d:
            c=Cache(d); c.save('X',self.f.tail(20)); pd.testing.assert_frame_equal(c.load('X').rename_axis(None),self.f.tail(20).astype(float),check_freq=False)
            r={'symbol':'X','candle':'now','action':'BUY SETUP'}
            self.assertTrue(c.record(r,'DEMO')); self.assertFalse(c.record(r,'DEMO')); self.assertTrue(c.record(r,'LIVE')); c.close()
    def test_no_order_endpoints(self):
        with self.assertRaises(DataError): Dhan('x','x',threading.Event()).request('/orders',{})
    def test_master_mapping(self):
        cols=['EXCH_ID','SEGMENT','INSTRUMENT','SECURITY_ID','UNDERLYING_SECURITY_ID','SYMBOL_NAME','SERIES']
        f=pd.DataFrame([['NSE','D','FUTSTK','88','42','ABC FUT',''],['NSE','E','EQUITY','42','','ABC','EQ'],['NSE','E','EQUITY','99','','OTHER','EQ'],['NSE','I','INDEX','13','','NIFTY 50','']],columns=cols)
        self.assertEqual({x['symbol'] for x in parse_master(f)},{'ABC','NIFTY 50'})

class FakePredictor:
    def predict(self,**kwargs):
        self.input=kwargs
        return pd.DataFrame({'close':np.repeat(kwargs['df'].close.iloc[-1]*1.01,kwargs['pred_len'])})

class KronosTests(unittest.TestCase):
    def setUp(self):
        f=demo_frame(); self.now=f.index[-1].normalize()+pd.Timedelta(hours=14); self.b=bars(f,3,self.now)
    def test_ist_wall_clock_and_context(self):
        d,x,y=prepare(self.b)
        self.assertEqual(len(d),256); self.assertEqual(x.iloc[-1].hour,13); self.assertEqual(y.iloc[0].hour,14)
        self.assertIsNone(x.dt.tz); self.assertTrue((d.amount==d[['open','high','low','close']].mean(axis=1)*d.volume).all())
    def test_no_overnight_forecasts(self):
        f=demo_frame(); b=bars(f,3,f.index[-1]+pd.Timedelta(minutes=1))
        with self.assertRaises(ForecastError):prepare(b)
    def test_samples_not_probability(self):
        p=FakePredictor(); r=Forecaster(p).predict(self.b)
        self.assertEqual(r['bias'],'UP'); self.assertAlmostEqual(r['change_pct'],1)
        self.assertNotIn('confidence',r); self.assertEqual(len(r['timestamps']),10)
    def test_invalid_output_rejected(self):
        p=FakePredictor()
        with patch.object(p,'predict',return_value=pd.DataFrame({'close':[np.nan]*10})):
            with self.assertRaises(ForecastError):Forecaster(p).predict(self.b)
    def test_input_short(self):
        with self.assertRaises(ForecastError):prepare(self.b.tail(10))
    def test_predictor_contract(self):
        p=FakePredictor(); Forecaster(p).predict(self.b,paths=1)
        self.assertEqual(p.input['sample_count'],1); self.assertEqual(p.input['pred_len'],10)
        self.assertEqual(set(p.input['df'].columns),{'open','high','low','close','volume','amount'})

if __name__=='__main__':unittest.main()
