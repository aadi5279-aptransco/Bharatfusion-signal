import unittest
from unittest.mock import patch
import pandas as pd
from rsi_strategy import scan,confirm_rebound
import test_discovery as fixtures
NOW=fixtures.NOW
from compact_view import compact,strategy_rows

class RSIStrategyTests(unittest.TestCase):
 def setUp(self):
  helper=fixtures.InstitutionalTests();helper.setUp();self.daily=helper.d;self.frame=helper.f
  self.b,self.h,self.d=fixtures.SMCTests().fixture()
 def run_scan(self,m=70,w=70,d=41,b=None,now=NOW):
  with patch('rsi_strategy.rsi14',side_effect=[pd.Series([m]),pd.Series([w]),pd.Series([d])]),patch('rsi_strategy.bars',return_value=self.b if b is None else b):return scan(self.daily,self.frame,now)
 def test_positive_double_confirmation_and_ordered_levels(self):
  r=self.run_scan();self.assertTrue(r['eligible'],r);self.assertEqual(r['price_confirmation'],'PASS');self.assertEqual(r['strength_confirmation'],'PASS')
  self.assertLess(r['underlying_sl'],r['underlying_entry']);self.assertLess(r['underlying_entry'],r['underlying_t1']);self.assertLess(r['underlying_t1'],r['underlying_t2'])
 def test_daily_exact_boundaries_excluded(self):
  for d in (39,44,38,45):
   with self.subTest(d=d):self.assertFalse(self.run_scan(d=d)['matched'])
 def test_monthly_weekly_strict_above_60(self):
  self.assertFalse(self.run_scan(m=60)['matched']);self.assertFalse(self.run_scan(w=60)['matched'])
 def test_daily_below_40_allowed_no_crossover_rule(self):self.assertTrue(self.run_scan(d=39.5)['eligible'])
 def test_volume_confirmation_blocks_but_keeps_watchlist(self):
  b=self.b.copy();b.iloc[-1,b.columns.get_loc('volume')]=1;r=self.run_scan(b=b)
  self.assertTrue(r['matched']);self.assertFalse(r['eligible']);self.assertIn('Strength',r['reason']);self.assertIsNone(r['underlying_entry'])
 def test_price_confirmation_blocks(self):
  b=self.b.copy();b.iloc[-1,b.columns.get_loc('open')]=b.close.iloc[-1];r=self.run_scan(b=b)
  self.assertTrue(r['matched']);self.assertFalse(r['eligible']);self.assertIn('Price',r['reason'])
 def test_stale_confirmation_blocks(self):
  r=self.run_scan(now=NOW+pd.Timedelta(minutes=20));self.assertFalse(r['eligible']);self.assertIn('fresh',r['reason'])
 def test_partial_candle_ignored(self):
  future=self.b.iloc[-1:].copy();future.index+=pd.Timedelta(minutes=15);future[['open','high','low','close']]*=2
  self.assertEqual(self.run_scan(),self.run_scan(b=pd.concat([self.b,future])))
 def test_current_daily_candle_ignored(self):
  current=self.daily.iloc[-1:].copy();current.index=pd.DatetimeIndex([NOW.normalize()]);current[['open','high','low','close']]*=3
  with patch('rsi_strategy.bars',return_value=self.b):a=scan(self.daily,self.frame,NOW);b=scan(pd.concat([self.daily,current]),self.frame,NOW)
  self.assertEqual(a,b)
 def test_missing_recent_bar_blocks(self):
  r=self.run_scan(b=self.b.drop(self.b.index[-2]));self.assertFalse(r['eligible']);self.assertIn('contiguous',r['reason'])
 def test_outside_entry_window_watch_only(self):
  r=self.run_scan(now=NOW.normalize()+pd.Timedelta(hours=16));self.assertTrue(r['matched']);self.assertFalse(r['eligible'])
 def test_new_tab_cash_prices_and_routing(self):
  row=dict(self.run_scan(),symbol='TEST');r=compact(row,'RSI strategy');self.assertEqual(r['view_entry'],row['underlying_entry']);self.assertEqual(strategy_rows({'symbol':'TEST','rsi_row':row},'RSI strategy'),[row])
 def test_missing_monthly_history(self):self.assertFalse(scan(self.daily.tail(300),self.frame,NOW)['matched'])
if __name__=='__main__':unittest.main()
