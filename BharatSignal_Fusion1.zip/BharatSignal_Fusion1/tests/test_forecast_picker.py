import unittest,threading
from types import SimpleNamespace
from app import App

class Value:
 def __init__(self,value=''):self.value=value
 def get(self):return self.value
 def set(self,value):self.value=value
class Picker:
 def configure(self,**kw):self.values=kw['values']
class PickerTests(unittest.TestCase):
 def make(self):
  return SimpleNamespace(results={'NIFTY':{},'ABC':{}},forecasts={},forecast_picker=Picker(),forecast_symbol=Value(),redraw_forecast=lambda:None)
 def test_lists_instruments_without_any_predictions(self):
  a=self.make();App.refresh_forecast_picker(a);self.assertEqual(a.forecast_picker.values,['ABC','NIFTY']);self.assertEqual(a.forecast_symbol.get(),'ABC')
 def test_refresh_preserves_selection(self):
  a=self.make();a.forecast_symbol.set('NIFTY');a.forecasts={'ABC':{}};App.refresh_forecast_picker(a);self.assertEqual(a.forecast_symbol.get(),'NIFTY')
 def test_dropdown_forecasts_its_selection(self):
  a=self.make();a.forecast_symbol.set('NIFTY');a.results['NIFTY']={'symbol':'NIFTY'};calls=[];a.enqueue_forecast=calls.append
  App.predict_dropdown(a);self.assertEqual(calls,[{'symbol':'NIFTY'}])
 def test_no_data_explained(self):
  a=self.make();a.results={};a.forecast_progress=Value();App.predict_dropdown(a);self.assertIn('Start a scan',a.forecast_progress.get())
 def test_missing_context_explained_not_silent(self):
  calls=[];a=SimpleNamespace(stop=threading.Event(),forecast_notice=lambda s,m:calls.append(m))
  self.assertFalse(App.enqueue_forecast(a,{'symbol':'NIFTY'}));self.assertIn('60 complete',calls[0])
 def test_stopped_scanner_explained(self):
  calls=[];a=SimpleNamespace(stop=threading.Event(),forecast_notice=lambda s,m:calls.append(m));a.stop.set()
  self.assertFalse(App.enqueue_forecast(a,{'symbol':'NIFTY'}));self.assertIn('Scanner stopped',calls[0])
if __name__=='__main__':unittest.main()
