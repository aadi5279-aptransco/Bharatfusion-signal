import unittest
import pandas as pd
import numpy as np
from engine import IST
from timed_scans import daily_weekly,evaluate,ranked,status

class TimedScanTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.now=pd.Timestamp('2026-10-26 10:15',tz=IST)
  days=pd.bdate_range(end=cls.now.normalize(),periods=65)
  frames=[]
  for j,day in enumerate(days):
   idx=pd.date_range(day+pd.Timedelta(hours=9,minutes=15),periods=375,freq='min')
   c=100+j*.5+np.arange(375)*.0005
   frames.append(pd.DataFrame({'open':c-.02,'high':c+.1,'low':c-.1,'close':c,'volume':1000.},index=idx))
  cls.f=pd.concat(frames)
  cls.f.loc[cls.f.index.normalize()==cls.now.normalize(),'volume']=2500.
 def test_cutoff_1515(self):
  d,w,e=daily_weekly(self.f,self.now);f=self.f.copy();mask=f.index.hour*60+f.index.minute>=915
  f.loc[mask,['open','high','low','close']]*=3
  d2,w2,e2=daily_weekly(f,self.now);pd.testing.assert_frame_equal(d,d2);self.assertEqual(e,'')
 def test_current_week_excluded(self):
  d,w,e=daily_weekly(self.f,self.now);self.assertLess(w.index[-1],self.now.normalize())
 def test_missing_minutes_coverage_tolerance(self):
  day=self.f.index[-376].normalize();f=self.f.drop(pd.date_range(day+pd.Timedelta(hours=10),periods=5,freq='min'))
  d,w,e=daily_weekly(f,self.now);self.assertEqual(e,'')
 def test_incomplete_last_session_blocks(self):
  day=self.f.index[-376].normalize();f=self.f.drop(pd.date_range(day+pd.Timedelta(hours=10),periods=40,freq='min'))
  self.assertIn('incomplete',daily_weekly(f,self.now)[2])
 def test_release_times(self):
  a=evaluate(self.f,self.now.normalize()+pd.Timedelta(hours=9,minutes=44));self.assertIn('09:45',a['scan_reason'])
  a=evaluate(self.f,self.now-pd.Timedelta(minutes=1),True);self.assertIn('10:15',a['scan_reason'])
 def test_double_confirmed_targets(self):
  a=evaluate(self.f,self.now);self.assertTrue(a['timed_eligible'],a['scan_reason'])
  self.assertLess(a['plan_stop'],a['plan_entry']);self.assertLess(a['plan_entry'],a['plan_t1']);self.assertLess(a['plan_t1'],a['plan_t2'])
 def test_one_close_not_double_confirmation(self):
  f=self.f.copy();mask=(f.index>=self.now.normalize()+pd.Timedelta(hours=9,minutes=15))&(f.index<self.now.normalize()+pd.Timedelta(hours=9,minutes=30))
  f.loc[mask,['open','high','low','close']]-=2
  a=evaluate(f,self.now);self.assertFalse(a['timed_eligible']);self.assertIn('Both first',a['scan_reason'])
 def test_morning_levels_frozen(self):
  a=evaluate(self.f,self.now.normalize()+pd.Timedelta(hours=9,minutes=45))
  f=self.f.copy();mask=f.index>=self.now.normalize()+pd.Timedelta(hours=10)
  f.loc[mask,['open','high','low','close']]*=1.1
  b=evaluate(f,self.now+pd.Timedelta(hours=1))
  for k in ('plan_entry','plan_stop','plan_t1','plan_t2','plan_score'):self.assertEqual(a[k],b[k])
 def test_intraday_indicator_rejection_explained(self):
  a=evaluate(self.f,self.now,True);self.assertFalse(a['timed_eligible']);self.assertTrue(a['scan_reason'])
 def test_future_data_cannot_change_opening_selection(self):
  a=evaluate(self.f,self.now,True);f=self.f.copy();f.loc[f.index>=self.now,['open','high','low','close']]*=2
  self.assertEqual(a,evaluate(f,self.now,True))
 def test_separate_intraday_view_and_limit(self):
  rows=[dict(symbol=str(i),kind='stock',timed_eligible=False,intraday_plan=dict(timed_eligible=True,plan_score=i,plan_entry=10)) for i in range(25)]
  self.assertEqual(len(ranked(rows)),0);self.assertEqual(len(ranked(rows,10,True)),10)
 def test_empty_view_has_explanation(self):self.assertIn('No qualifying',status([]))
 def test_intraday_four_candle_positive_case(self):
  f=self.f.copy();idx=f.index[f.index.normalize()<self.now.normalize()][-300:]
  shift=np.sin(np.arange(300)/15*2)*.3
  for c in ('open','high','low','close'):f.loc[idx,c]+=shift
  fourth=(f.index>=self.now-pd.Timedelta(minutes=15))&(f.index<self.now)
  f.loc[fourth,['open','high','low','close']]+=.25
  a=evaluate(f,self.now,True);self.assertTrue(a['timed_eligible'],a['scan_reason'])
  self.assertEqual(a['plan_asof'],'2026-10-26T10:00:00+05:30');self.assertLess(a['plan_t1'],a['plan_t2'])
 def test_missing_opening_minute_rejects_four_candle_signal(self):
  f=self.f.drop(self.now-pd.Timedelta(minutes=1))
  a=evaluate(f,self.now,True);self.assertFalse(a['timed_eligible']);self.assertIn('first 4 complete',a['scan_reason'])
if __name__=='__main__':unittest.main()
