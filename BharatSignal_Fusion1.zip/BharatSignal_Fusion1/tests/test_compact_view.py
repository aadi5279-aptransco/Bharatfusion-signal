import unittest
from compact_view import compact,details,COLUMNS
class CompactTests(unittest.TestCase):
 def test_option_missing_quote_never_substitutes_underlying(self):
  r=compact(dict(symbol='ABC',strategy='Bear trap CE',option_side='CE',underlying_entry=100,matched=True,eligible=False,reason='No current option-entry quote for historical setup'),'Stock options')
  self.assertIsNone(r['view_entry']);self.assertIn('historical',r['view_status']);self.assertIn('option premium',details(r))
 def test_cash_displays_cash_levels(self):
  r=compact(dict(strategy='125D breakout',underlying_entry=100,underlying_t1=102,underlying_t2=104,underlying_sl=98,eligible=True),'BTST stocks')
  self.assertEqual(r['view_entry'],100);self.assertEqual(r['contract'],'Cash stock');self.assertEqual(len(COLUMNS),8)
 def test_option_prices_and_hidden_details_retained(self):
  original=dict(symbol='ABC',strategy='Bear trap CE',option_side='CE',atm_strike=100.,premium_entry=5,premium_t1_est=6,expiry='2026-11-24',quantity=100,matched=True,eligible=False,reason='F&O ban check: UNKNOWN')
  r=compact(original,'Stock options');self.assertEqual(r['view_entry'],5);self.assertEqual(r['view_t1'],6);self.assertIn('UNKNOWN',r['view_status']);self.assertIn('2026-11-24',details(r));self.assertFalse(original['eligible'])
 def test_intraday_uses_its_own_plan(self):
  r=compact(dict(plan_entry=99,intraday_plan={'plan_entry':101,'plan_status':'WAIT'}),'Intraday Top 10');self.assertEqual(r['view_entry'],101)
