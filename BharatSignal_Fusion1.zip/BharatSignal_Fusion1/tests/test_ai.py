import unittest,tempfile
import numpy as np
import pandas as pd
from engine import demo_frame,bars,IST
from ml_engine import matrix,labels,splits,model_dir,ModelService,BASE,BOOK
from sentiment import risk_overlay,suggested_units,SentimentService
from market_dashboard import summary,SECTORS
from screening import confirm
from tests.test_screening import row,forecast,NOW

class MLDataTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  f=demo_frame();cls.b=bars(f,3,f.index[-1]+pd.Timedelta(minutes=1))
 def test_feature_no_future_leakage(self):
  a=matrix(self.b.iloc[:500]);changed=self.b.copy();changed.iloc[500:,0:4]*=3
  pd.testing.assert_frame_equal(a,matrix(changed).iloc[:500])
 def test_depth_backward_only(self):
  b=self.b.tail(5);end=b.index[-1]+pd.Timedelta(minutes=3)
  book=pd.DataFrame({'spread_bps':[4.,99.],'book_imbalance':[.2,.9]},index=pd.DatetimeIndex([end-pd.Timedelta(seconds=10),end+pd.Timedelta(seconds=1)]))
  x=matrix(b,book);self.assertEqual(x.spread_bps.iloc[-1],4.)
 def test_missing_depth_not_zero(self):self.assertTrue(matrix(self.b)[BOOK].isna().all().all())
 def test_labels_do_not_cross_sessions(self):
  y=labels(self.b);self.assertTrue(all(a.date()==z.date() for a,z in zip(y.index,y.label_end)))
 def test_splits_purge_outcome_windows(self):
  d=matrix(self.b)[BASE].join(labels(self.b),how='inner');tr,va,ca,te=splits(d)
  for a,b in zip((tr,va,ca),(va,ca,te)):self.assertLess(a.label_end.max(),b.index.min())
 def test_short_training_blocked(self):
  with self.assertRaises(ValueError):splits(matrix(self.b).join(labels(self.b),how='inner').head(100))
 def test_registry_key_scope(self):
  self.assertNotEqual(model_dir('/tmp','NIFTY',3,'LONG'),model_dir('/tmp','NIFTY',5,'LONG'))
 def test_untrained_never_passes(self):
  with tempfile.TemporaryDirectory() as root:self.assertFalse(ModelService(root).predict(self.b,'X')['pass_gate'])
 def test_ml_additional_gate(self):
  r=row();r['ml_required']=True;r['ml']={'pass_gate':False};confirm(r,forecast(r),NOW)
  self.assertEqual(r['action'],'WAIT');self.assertIsNone(r['entry'])
 def test_ml_agreement_does_not_bypass_fundamentals(self):
  r=row();r['ml_required']=True;r['ml']={'pass_gate':True};r['fundamentals']={'status':'FAIL'};confirm(r,forecast(r),NOW);self.assertEqual(r['action'],'WAIT')

class SentimentTests(unittest.TestCase):
 def test_missing_news_reduces_risk(self):self.assertEqual(risk_overlay({},'X')['factor'],.5)
 def test_wrong_symbol_not_applied(self):
  n={'status':'READY','fetched_at':NOW.isoformat(),'items':[{'symbol':'Y','score':-1,'category':'companies'}]}
  self.assertEqual(risk_overlay(n,'X',now=NOW)['status'],'NO MATCHING NEWS')
 def test_adverse_news_blocks_size(self):
  n={'status':'READY','fetched_at':NOW.isoformat(),'items':[{'symbol':'X','score':-.9,'category':'companies'}]}
  self.assertEqual(risk_overlay(n,'X',now=NOW)['factor'],0)
 def test_positive_news_never_leverages(self):
  n={'status':'READY','fetched_at':NOW.isoformat(),'items':[{'symbol':'X','score':.99,'category':'companies'}]}
  self.assertEqual(risk_overlay(n,'X',now=NOW)['factor'],1)
 def test_risk_budget_cap(self):self.assertEqual(suggested_units(100000,.5,100,99,.5),250)
 def test_no_index_share_quantity(self):self.assertIsNone(suggested_units(100000,.5,100,99,1,'index'))
 def test_no_invalid_size(self):self.assertIsNone(suggested_units(100000,10,100,99,1))
 def test_freshness_and_duplicates(self):
  service=SentimentService();service.score=lambda t:{'score':.2}
  i={'publishDate':'2026-10-26','newsObject':{'title':'Example','text':'test'}}
  old={'publishDate':'2020-01-01','newsObject':{'title':'Old'}}
  result=service.analyze([i,i,old],NOW);self.assertEqual(len(result['items']),1)

class DashboardTests(unittest.TestCase):
 def test_bias_blocks_missing_coverage(self):self.assertEqual(summary([row()],200,NOW)['bias'],'WAIT / INCOMPLETE')
 def test_bias_with_measured_coverage(self):
  rows=[row(i) for i in range(10)];n=row(kind='index');n['symbol']='NIFTY';rows.append(n)
  for sector in list(SECTORS.values())[:3]:
   r=row(kind='sector');r['sector']=sector;rows.append(r)
  self.assertEqual(summary(rows,10,NOW)['bias'],'BULLISH')
 def test_stale_sectors_not_ranked(self):
  r=row(kind='sector');r['sector']='IT';self.assertEqual(summary([r],10,NOW+pd.Timedelta(hours=1))['sectors'],[])

if __name__=='__main__':unittest.main()
