import unittest,json,tempfile,threading
from unittest.mock import patch
import numpy as np
import pandas as pd
from discovery_rules import institutional,completed_periods,levels,smc_setup,ai_selected
from scanx_source import parse_snapshot,EXPECTED,HEADERS
from engine import IST,features
from compact_view import compact,strategy_rows
NOW=pd.Timestamp('2026-10-30 14:00',tz=IST)

def fixture_html(rows=None,total=None,params=None):
 row=['NSE',123,'E','EQUITY',1,.05,1,'Test Ltd','ISIN','slug',100,1,1,1000,110,90,20,2000,3,.1,.2,0,4,20,12,.2,15,'TEST']
 rows=[row] if rows is None else rows
 state={'meta':{'u':'https://screeners-public-api.scanx.trade/txnws/screener/getDetails','b':{'data':[{'screener_id':453307,'filters':{'logic_op':'AND','params':params or [dict(field=k,op=v[0],val=v[1]) for k,v in EXPECTED.items()]}}]}},'result':{'u':'https://ow-scanx-analytics.dhan.co/customscan/v2/fetchdt','b':dict(headers=HEADERS,data=rows,tot_rec=len(rows) if total is None else total,tot_pg=1,last_resp_time='30-10-2026 13:59:00')}}
 return '<script id="ng-state" type="application/json">'+json.dumps(state)+'</script>'

class SourceTests(unittest.TestCase):
 def test_verified_snapshot(self):self.assertEqual(parse_snapshot(fixture_html(),NOW)['123']['symbol'],'TEST')
 def test_index_ticker_snapshot_is_not_the_screener(self):
  html=fixture_html();state=json.loads(html.split('>',1)[1].split('</script>')[0]);state['ticker']={'u':'https://ow-scanx-analytics.dhan.co/customscan/v2/fetchdt','b':{'headers':['Exch','Sid'],'data':[['IDX',25]]}}
  html='<script id="ng-state">'+json.dumps(state)+'</script>'
  self.assertEqual(len(parse_snapshot(html,NOW)),1)
 def test_stale_source_rejected(self):
  with self.assertRaisesRegex(ValueError,'timestamp'):parse_snapshot(fixture_html(),NOW+pd.Timedelta(hours=1))
 def test_future_source_rejected(self):
  with self.assertRaisesRegex(ValueError,'timestamp'):parse_snapshot(fixture_html(),NOW-pd.Timedelta(hours=1))
 def test_pagination_not_silently_truncated(self):
  with self.assertRaisesRegex(ValueError,'paginated'):parse_snapshot(fixture_html(total=30),NOW)
 def test_changed_filters_rejected(self):
  with self.assertRaisesRegex(ValueError,'filters changed'):parse_snapshot(fixture_html(params=[dict(field='Mcap',op='gte',val='10')]),NOW)
 def test_zero_results_valid(self):self.assertEqual(parse_snapshot(fixture_html(rows=[]),NOW),{})
 def test_no_html_fallback_universe(self):
  with self.assertRaises(ValueError):parse_snapshot('<html>Login</html>',NOW)

class InstitutionalTests(unittest.TestCase):
 def setUp(self):
  idx=pd.bdate_range(end=NOW.normalize()-pd.Timedelta(days=1),periods=1300);c=np.linspace(60,100,len(idx))
  self.d=pd.DataFrame(dict(open=c-.1,high=c+.2,low=c-.2,close=c,volume=10000),index=idx)
  idx=pd.date_range(NOW.normalize()+pd.Timedelta(hours=9,minutes=15),NOW-pd.Timedelta(minutes=1),freq='min');c=np.linspace(100,101,len(idx))
  self.f=pd.DataFrame(dict(open=c-.01,high=c+.05,low=c-.05,close=c,volume=100.),index=idx)
 def rsi(self,values):
  n=len(values);r=pd.Series(70.,index=values.index)
  if n>400:r.iloc[-2:]=[39.5,41.]
  return r
 def test_positive_provisional_cross(self):
  with patch('discovery_rules.rsi14',side_effect=self.rsi):r=institutional(self.d,self.f,NOW,True)
  self.assertTrue(r['eligible'],r);self.assertIn('PROVISIONAL',r['reason']);self.assertLess(r['underlying_sl'],r['underlying_entry']);self.assertGreater(r['underlying_t2'],r['underlying_t1'])
 def test_membership_required(self):self.assertFalse(institutional(self.d,self.f,NOW,False)['matched'])
 def test_current_month_week_excluded(self):
  a,b=completed_periods(self.d,NOW);self.assertLess(a.index[-1],NOW.normalize().replace(day=1));self.assertLess(b.index[-1],NOW.normalize()-pd.Timedelta(days=NOW.weekday()))
 def test_monthly_warmup(self):self.assertIn('completed',institutional(self.d.tail(500),self.f,NOW,True)['reason'])
 def test_low_volume_blocks(self):
  self.f['volume']=1
  with patch('discovery_rules.rsi14',side_effect=self.rsi):r=institutional(self.d,self.f,NOW,True)
  self.assertFalse(r['eligible']);self.assertIn('volume',r['reason'])
 def test_missing_minute_blocks(self):self.assertFalse(institutional(self.d,self.f.iloc[1:],NOW,True)['eligible'])
 def test_no_cross_above_40_already(self):
  def already(v):
   r=self.rsi(v)
   if len(v)>400:r.iloc[-2]=41
   return r
  with patch('discovery_rules.rsi14',side_effect=already):r=institutional(self.d,self.f,NOW,True)
  self.assertFalse(r['eligible']);self.assertIn('prior completed daily RSI',r['reason'])
 def test_future_minutes_ignored(self):
  future=self.f.iloc[-5:].copy();future.index=future.index+pd.Timedelta(hours=2);future[['open','high','low','close']]*=3
  with patch('discovery_rules.rsi14',side_effect=self.rsi):
   a=institutional(self.d,self.f,NOW,True);b=institutional(self.d,pd.concat([self.f,future]),NOW,True)
  self.assertEqual(a,b)
 def test_large_structural_stop_rejected(self):
  r=levels('X',100,80,2,NOW,'test',self.d);self.assertFalse(r['eligible']);self.assertIsNone(r['underlying_sl'])
 def test_new_tab_price_mapping(self):
  r=compact(dict(symbol='ABC',strategy='Institutional RSI pullback',underlying_entry=100,eligible=True),'Institutional stocks');self.assertEqual(r['view_entry'],100)

class CachedTabsTests(unittest.TestCase):
 def test_new_tabs_only_render_cached_rows(self):
  from types import SimpleNamespace
  from unittest.mock import Mock
  from app import App
  for tab,key in [('Institutional stocks','institutional_row'),('AI selected stocks','ai_row'),('RSI strategy','rsi_row')]:
   tree=Mock();tree.selection.return_value=();tree.get_children.return_value=();tree.exists.return_value=False
   base=dict(symbol='ABC',kind='stock');base[key]=dict(symbol='ABC',strategy='Test',matched=True,eligible=False,reason='Awaiting confirmation')
   app=SimpleNamespace(tables={tab:tree},book=Mock(),results={'ABC':base},table_columns={tab:('symbol','view_entry','view_status')},rendered_values={},scan_labels={tab:Mock()},strategy_lookup={},show_blocked=Mock(),refresh_dashboard=Mock(),scan=Mock(),start=Mock())
   app.show_blocked.get.return_value=False;app.book.tab.return_value=tab
   App._render_now(app);tree.insert.assert_called_once();app.scan.assert_not_called();app.start.assert_not_called()
 def test_wilder_seed_and_warmup(self):
  from discovery_rules import rsi14
  close=pd.Series([100,101,100,102,101,103,102,104,103,105,104,106,105,107,106],dtype=float)
  result=rsi14(close);self.assertTrue(result.iloc[:14].isna().all())
  delta=close.diff().iloc[1:];gain=delta.clip(lower=0).mean();loss=(-delta.clip(upper=0)).mean()
  self.assertAlmostEqual(result.iloc[-1],100-100/(1+gain/loss))

class SMCTests(unittest.TestCase):
 def fixture(self):
  # Explicit descending local structure, sell-side sweep, then bullish displacement.
  idx=pd.date_range(end=NOW-pd.Timedelta(minutes=15),periods=90,freq='15min');c=np.linspace(96,100,90)
  b=pd.DataFrame(dict(open=c-.02,high=c+.15,low=c-.15,close=c,volume=100.),index=idx)
  b.iloc[-8:-3,b.columns.get_loc('close')]=[99.7,99.6,99.5,99.4,99.3]
  for i in range(len(b)-8,len(b)-3):
   b.iloc[i,b.columns.get_loc('open')]=b.close.iloc[i]+.04;b.iloc[i,b.columns.get_loc('high')]=b.close.iloc[i]+.15;b.iloc[i,b.columns.get_loc('low')]=b.close.iloc[i]-.15
  j=len(b)-3;b.iloc[j]=[99.4,99.8,98.4,99.5,200]
  b.iloc[-2]=[99.5,99.9,99.4,99.8,100];b.iloc[-1]=[99.8,101.1,99.75,101,400]
  hidx=pd.date_range(end=NOW-pd.Timedelta(hours=1),periods=50,freq='h');c=np.linspace(90,100,50);h=pd.DataFrame(dict(open=c-.05,high=c+.2,low=c-.2,close=c,volume=100.),index=hidx)
  didx=pd.bdate_range(end=NOW.normalize()-pd.Timedelta(days=1),periods=100);c=np.linspace(80,100,100);d=pd.DataFrame(dict(open=c-.1,high=c+.2,low=c-.2,close=c,volume=1000.),index=didx)
  return b,h,d
 def test_sweep_choc_positive(self):
  b,h,d=self.fixture();r=smc_setup(b,h,d,NOW);self.assertTrue(r['eligible'],r);self.assertIn('CHoCH',r['strategy'])
 def test_bos_fvg_retest_positive(self):
  b,h,d=self.fixture();b.iloc[-3]=[100.4,101.4,100.2,101.2,250];b.iloc[-2]=[101.1,101.8,100.4,101.5,100];b.iloc[-1]=[100.9,102.2,100.1,102.1,500]
  r=smc_setup(b,h,d,NOW);self.assertTrue(r['eligible'],r);self.assertIn('FVG',r['strategy'])
 def test_already_mitigated_gap_rejected(self):
  b,h,d=self.fixture();b.iloc[-3]=[100.4,101.4,100.2,101.2,250];b.iloc[-2]=[101.1,101.8,100.1,101.2,100];b.iloc[-1]=[100.9,102.2,100.1,102.1,500]
  self.assertFalse(smc_setup(b,h,d,NOW)['eligible'])
 def test_no_volume_blocks(self):
  b,h,d=self.fixture();b.iloc[-1,b.columns.get_loc('volume')]=1;self.assertFalse(smc_setup(b,h,d,NOW)['eligible'])
 def test_stale_blocks(self):
  b,h,d=self.fixture();self.assertFalse(smc_setup(b,h,d,NOW+pd.Timedelta(minutes=20))['eligible'])
 def test_future_candles_ignored(self):
  b,h,d=self.fixture();future=b.iloc[-1:].copy();future.index=future.index+pd.Timedelta(minutes=30);future[['open','high','low','close']]*=3
  self.assertEqual(smc_setup(b,h,d,NOW),smc_setup(pd.concat([b,future]),h,d,NOW))
 def test_ai_requires_validated_ml_context(self):
  with patch('discovery_rules.bars',return_value=pd.DataFrame()),patch('discovery_rules.smc_setup',return_value=dict(eligible=True,matched=True,reason='SMC')):
   r=ai_selected(None,None,NOW,{'status':'NOT TRAINED','pass_gate':False})
  self.assertFalse(r['eligible']);self.assertIn('ML',r['reason'])
if __name__=='__main__':unittest.main()
