import unittest,tempfile
import pandas as pd
from engine import demo_frame,bars,IST
from breakout import previous_session,plan,ranked,forecast_targets
from training_queue import AutoTraining
from kronos_adapter import prepare,ForecastError

class BreakoutTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.f=demo_frame(4);cls.now=cls.f.index[-1].normalize()+pd.Timedelta(hours=12)
 def test_previous_day_excludes_today(self):
  a=previous_session(self.f,self.now);f=self.f.copy();f.loc[f.index.normalize()==self.now.normalize(),['open','high','low','close']]*=4
  self.assertEqual(a,previous_session(f,self.now));self.assertLess(pd.Timestamp(a['date']).date(),self.now.date())
 def test_partial_prior_session_rejected(self):
  prior=previous_session(self.f,self.now);stamp=pd.Timestamp(prior['date'],tz=IST)+pd.Timedelta(hours=10)
  self.assertIsNone(previous_session(self.f.drop(stamp),self.now))
 def test_future_candles_cannot_change_plan(self):
  a=plan(self.f,self.now);f=self.f.copy();f.loc[f.index>=self.now,['open','high','low','close']]*=4
  self.assertEqual(a,plan(f,self.now))
 def frame_broken(self,up=True):
  f=self.f.copy();prior=previous_session(f,self.now);price=prior['high']+1 if up else prior['low']-1
  mask=(f.index>=self.now-pd.Timedelta(minutes=3))&(f.index<self.now)
  f.loc[mask,'open']=price;f.loc[mask,'close']=price;f.loc[mask,'high']=price+.1;f.loc[mask,'low']=price-.1;f.loc[mask,'volume']=1000000
  return f
 def test_breakout_targets_order(self):
  p=plan(self.frame_broken(),self.now);self.assertEqual(p['plan_direction'],'LONG');self.assertTrue(p['plan_status'].startswith('BREAKOUT'))
  self.assertLess(p['plan_stop'],p['plan_entry']);self.assertLess(p['plan_entry'],p['plan_t1']);self.assertLess(p['plan_t1'],p['plan_t2'])
 def test_breakdown_targets_order(self):
  p=plan(self.frame_broken(False),self.now);self.assertEqual(p['plan_direction'],'SHORT');self.assertTrue(p['plan_status'].startswith('BREAKDOWN'))
  self.assertGreater(p['plan_stop'],p['plan_entry']);self.assertGreater(p['plan_entry'],p['plan_t1']);self.assertGreater(p['plan_t1'],p['plan_t2'])
 def test_intraday_needs_volume(self):
  f=self.frame_broken();mask=(f.index>=self.now-pd.Timedelta(minutes=3))&(f.index<self.now);f.loc[mask,'volume']=1
  self.assertFalse(plan(f,self.now)['intraday_eligible'])
 def test_watch_does_not_imply_intraday(self):
  p=plan(self.f,self.now.normalize()+pd.Timedelta(hours=9));self.assertFalse(p['intraday_eligible']);self.assertIn('WATCH',p['plan_status'])
 def test_index_does_not_require_volume(self):
  f=self.frame_broken();f.volume=0;p=plan(f,self.now,'index');self.assertTrue(p['plan_status'].startswith('BREAKOUT'));self.assertIsNotNone(p['plan_t2'])
 def test_rank_limit_and_stale_intraday(self):
  p=plan(self.frame_broken(),self.now);rows=[dict(p,symbol=f'S{i}',kind='stock',mode='DHAN LIVE') for i in range(30)]
  self.assertEqual(len(ranked(rows,now=self.now)),20)
  self.assertLessEqual(len(ranked(rows,10,True,self.now)),10)
  self.assertEqual(ranked(rows,10,True,self.now+pd.Timedelta(hours=1)),[])
 def test_new_candle_intervals(self):
  for minutes in (15,60,240):
   b=bars(self.f,minutes,self.now);self.assertTrue(len(b)>0)
   self.assertTrue(all(t.hour*60+t.minute>=555 and t.hour*60+t.minute+minutes<=930 for t in b.index))
  b=bars(self.f,240,self.now+pd.Timedelta(hours=3));self.assertTrue(all(t.hour==9 and t.minute==15 for t in b.index))
 def test_kronos_new_intervals(self):
  for minutes in (15,60):
   b=bars(self.f,minutes,self.now);d,x,y=prepare(b,minutes);self.assertGreater(len(y),0)
 def test_240_does_not_invent_overnight(self):
  f=pd.concat([self.f.set_axis(self.f.index-pd.Timedelta(days=100)),self.f.set_axis(self.f.index-pd.Timedelta(days=80)),self.f.set_axis(self.f.index-pd.Timedelta(days=60)),self.f.set_axis(self.f.index-pd.Timedelta(days=40)),self.f.set_axis(self.f.index-pd.Timedelta(days=20)),self.f]).sort_index()
  b=bars(f,240,self.now+pd.Timedelta(hours=3))
  with self.assertRaisesRegex(ForecastError,'No complete candles'):prepare(b,240)
 def test_model_targets_are_actual_path_extremes(self):
  f={'bias':'UP','last':100,'median':[101,103,102,106]};t=forecast_targets(f)
  self.assertEqual(t['kronos_t1'],103);self.assertEqual(t['kronos_t2'],106)
  self.assertEqual(forecast_targets({'bias':'FLAT','last':100,'median':[100]}),{})
 def test_down_targets(self):
  t=forecast_targets({'bias':'DOWN','last':100,'median':[99,97,98,94]});self.assertEqual((t['kronos_t1'],t['kronos_t2']),(97,94))
 def test_training_coalesces_and_persists_attempts(self):
  with tempfile.TemporaryDirectory() as root:
   q=AutoTraining(root);r=dict(symbol='X',minutes=240,ml_minutes=3,mode='DHAN LIVE',cache_key='X',ml={'status':'NOT TRAINED'})
   q.enqueue([r,r]);self.assertEqual(len(q.pending),1);self.assertEqual(q.pop()['symbol'],'X')
   q=AutoTraining(root);q.enqueue([r]);self.assertFalse(q.pending)
 def test_training_never_queues_demo_or_valid_model(self):
  with tempfile.TemporaryDirectory() as root:
   q=AutoTraining(root)
   q.enqueue([dict(symbol='A',minutes=3,mode='DEMO'),dict(symbol='B',minutes=3,mode='DHAN LIVE',cache_key='B',ml={'status':'AGREE'})]);self.assertFalse(q.pending)
 def test_queue_caps_and_replaces_outdated_selection(self):
  with tempfile.TemporaryDirectory() as root:
   q=AutoTraining(root)
   rows=[dict(symbol=f'S{i}',minutes=3,mode='DHAN LIVE',cache_key=str(i),ml={'status':'NOT TRAINED'}) for i in range(30)]
   q.enqueue(rows);self.assertEqual(len(q.pending),25)
   q.enqueue(rows[-2:]);self.assertEqual({r['symbol'] for r in q.pending.values()},{'S28','S29'})
 def test_plans_survive_chart_warmup_but_not_stop(self):
  p=plan(self.f,self.now)
  r=dict(p,symbol='X',kind='stock',active=False,plan_active=True)
  self.assertEqual(len(ranked([r])),1)
  r['plan_active']=False;self.assertEqual(ranked([r]),[])
if __name__=='__main__':unittest.main()
