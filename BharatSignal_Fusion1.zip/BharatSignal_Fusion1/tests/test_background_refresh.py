import unittest,threading,tempfile
from types import SimpleNamespace
from unittest.mock import Mock
import pandas as pd
from refresh_schedule import next_refresh
from paper_watch import PaperWatch
from engine import IST
from app import App

class BackgroundTests(unittest.TestCase):
 def test_short_scan_keeps_five_minute_start_grid(self):self.assertEqual(next_refresh(100,145),400)
 def test_overrun_skips_missed_slots(self):
  self.assertEqual(next_refresh(100,750),1000)
  self.assertEqual(next_refresh(100,400),700)
 def test_cached_tab_render_does_not_start_scan(self):
  tree=Mock();tree.selection.return_value=();tree.get_children.return_value=();tree.exists.return_value=False
  app=SimpleNamespace(tables={'Indices':tree},book=Mock(),results={'NIFTY':dict(symbol='NIFTY',kind='index',action='WAIT')},table_columns={'Indices':['symbol','action']},rendered_values={},refresh_dashboard=Mock(),scan=Mock(),start=Mock())
  app.book.tab.return_value='Indices'
  App._render_now(app)
  tree.insert.assert_called_once();app.scan.assert_not_called();app.start.assert_not_called();app.refresh_dashboard.assert_not_called()
 def test_slow_paper_quote_does_not_hold_ui_lock_or_overwrite_new_position(self):
  now=pd.Timestamp('2026-10-30 10:15',tz=IST)
  frame=pd.DataFrame(columns=['open','high','low','close','volume'],index=pd.DatetimeIndex([],tz=IST))
  entered=threading.Event();release=threading.Event()
  with tempfile.TemporaryDirectory() as root:
   watch=PaperWatch(root);row=dict(symbol='ABC',strategy='Bear trap',option_id='123',underlying_sl=90)
   watch.add(row,30,100,now=now)
   def quotes(items):
    entered.set();release.wait(2)
    return {'NSE_FNO':{'123':dict(last_trade_time=now.isoformat(),depth={'buy':[{'price':5}]})}}
   alerts=[]
   thread=threading.Thread(target=lambda:alerts.extend(watch.monitor({'symbol':'ABC'},frame,None,None,SimpleNamespace(quotes=quotes),now)))
   thread.start();self.assertTrue(entered.wait(2))
   acquired=watch.lock.acquire(timeout=.1)
   try:self.assertTrue(acquired,'Network operation must not lock GUI controls')
   finally:
    if acquired:watch.lock.release()
    release.set()
   watch.add(dict(row,symbol='XYZ'),30,100,now=now)
   thread.join(3);self.assertFalse(thread.is_alive());self.assertEqual(len(watch.read()),2)
   self.assertTrue(any('2,000' in x for x in alerts))
if __name__=='__main__':unittest.main()
