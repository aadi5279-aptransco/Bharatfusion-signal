import unittest,copy,threading
from unittest.mock import patch
import pandas as pd
from screening import top_momentum,confirm,assess_fundamentals,momentum_metrics
from forecast_queue import ForecastQueue
from forecast_chart import draw_forecast
from data import Dhan,DataError
from engine import IST

NOW=pd.Timestamp('2026-10-26 12:00',tz=IST)
def row(i=0,kind='stock'):
 return dict(symbol=str(i),kind=kind,mode='DHAN LIVE',minutes=3,candle=(NOW-pd.Timedelta(minutes=3)).isoformat(),action='BUY SETUP',
             bias='BULL',htf={'15':'BULL','30':'BULL','60':'BULL'},rvol=2.,roc5=1.,session_change=2.,momentum=100-i,turnover=1e7,
             entry=100,stop=99,t1=101.5,t2=102.5,fundamentals={'status':'PASS'})
def forecast(r):return dict(mode=r['mode'],asof=r['candle'],bias='UP')
def fundamental():
 return dict(fetched_at=NOW.isoformat(),data={'CO':{'EPS':20,'SECTOR':'Manufacturing'},'RATIOS':{'ROE':15,'ROCE':16,'DEBT_TO_EQUITY':.5,'PE_RATIO':20,'PE_TO_SECTOR_PE':1.1}})

class ScreeningTests(unittest.TestCase):
 def test_top20_hard_limit(self):self.assertEqual(len(top_momentum([row(i) for i in range(40)],now=NOW)),20)
 def test_ranking(self):self.assertEqual([r['symbol'] for r in top_momentum([row(3),row(1),row(2)],now=NOW)],['1','2','3'])
 def test_indices_separate(self):self.assertEqual(len(top_momentum([row(1,'index')],now=NOW)),0)
 def test_no_padding_low_volume(self):
  r=row();r['rvol']=1.49;self.assertEqual(top_momentum([r],now=NOW),[])
 def test_no_negative_momentum(self):
  r=row();r['roc5']=-1;self.assertEqual(top_momentum([r],now=NOW),[])
 def test_no_stale_ranking(self):self.assertEqual(top_momentum([row()],now=NOW+pd.Timedelta(minutes=8)),[])
 def test_no_inactive_ranking(self):
  r=row();r['active']=False;self.assertEqual(top_momentum([r],now=NOW),[])
 def test_three_checks_pass(self):
  r=row();confirm(r,forecast(r),NOW);self.assertEqual(r['confirmation'],'3/3');self.assertEqual(r['entry'],100)
 def test_missing_fundamental_blocks_buy(self):
  r=row();r['fundamentals']={'status':'UNAVAILABLE'};confirm(r,forecast(r),NOW)
  self.assertEqual(r['action'],'WAIT');self.assertIsNone(r['entry']);self.assertEqual(r['confirmation'],'2/3')
 def test_model_disagreement_blocks(self):
  r=row();f=forecast(r);f['bias']='DOWN';confirm(r,f,NOW);self.assertEqual(r['action'],'WAIT')
 def test_old_model_blocks(self):
  r=row();f=forecast(r);f['asof']='2020-01-01';confirm(r,f,NOW);self.assertEqual(r['kronos_check'],'STALE')
 def test_three_htfs_required(self):
  r=row();r['htf']['60']='BEAR';confirm(r,forecast(r),NOW);self.assertEqual(r['technical_check'],'WAIT')
 def test_index_two_checks_not_fake_fundamental(self):
  r=row(kind='index');confirm(r,forecast(r),NOW);self.assertEqual(r['confirmation'],'2/2 (index)');self.assertEqual(r['fundamental_check'],'N/A')
 def test_reconfirmation_preserves_levels(self):
  r=row();confirm(r,None,NOW);self.assertIsNone(r['entry']);confirm(r,forecast(r),NOW);self.assertEqual(r['entry'],100)
 def test_fundamental_numeric_parsing(self):self.assertEqual(assess_fundamentals(fundamental(),now=NOW)['status'],'PASS')
 def test_fundamental_failure(self):
  f=fundamental();f['data']['CO']['EPS']=-1;self.assertEqual(assess_fundamentals(f,now=NOW)['status'],'FAIL')
 def test_missing_metrics_not_zero(self):
  f=fundamental();del f['data']['RATIOS']['ROE'];self.assertEqual(assess_fundamentals(f,now=NOW)['status'],'UNAVAILABLE')
 def test_fundamental_expiry(self):self.assertEqual(assess_fundamentals(fundamental(),now=NOW+pd.Timedelta(days=2))['status'],'STALE')
 def test_financial_sector_rules(self):
  f=fundamental();f['data']['CO']['SECTOR']='Banking';del f['data']['RATIOS']['DEBT_TO_EQUITY'];del f['data']['RATIOS']['ROCE']
  self.assertEqual(assess_fundamentals(f,now=NOW)['status'],'PASS')
 def test_endpoint_contract(self):
  api=Dhan('dummy','dummy',threading.Event());item={'id':'1333','segment':'NSE_EQ'}
  with patch.object(api,'request',return_value={'securityId':'1333','data':{}}) as req:
   api.company_info(item);self.assertEqual(req.call_args[0][0],'/data/companyinfo');self.assertEqual(req.call_args[0][1]['metrics'],['CO','RATIOS','SHP'])
 def test_endpoint_id_mismatch(self):
  api=Dhan('dummy','dummy',threading.Event())
  with patch.object(api,'request',return_value={'securityId':'999','data':{}}):
   with self.assertRaises(DataError):api.company_info({'id':'1333','segment':'NSE_EQ'})
 def test_queue_capacity_and_coalescing(self):
  q=ForecastQueue(25)
  for i in range(25):self.assertTrue(q.put((row(i),3)))
  r=row(0);r['momentum']=999;self.assertTrue(q.put((r,3)))
  self.assertEqual(q.size(),25);self.assertFalse(q.put((row(26),3)))
  self.assertEqual(q.get()[0]['momentum'],999);self.assertEqual(q.get()[0]['symbol'],'1')
 def test_queue_clear(self):
  q=ForecastQueue();q.put((row(),3));q.clear();self.assertEqual(q.size(),0)

class Canvas:
 def __init__(self):self.calls=[]
 def winfo_width(self):return 900
 def winfo_height(self):return 300
 def delete(self,*args):self.calls=[]
 def __getattr__(self,key):
  def call(*args,**kw):self.calls.append((key,args,kw))
  return call
class ChartTests(unittest.TestCase):
 def test_forecast_boundary_and_band(self):
  c=Canvas();history=[dict(time='2026-10-26T11:57:00+05:30',open=100,high=102,low=99,close=101)]
  draw_forecast(c,history,dict(median=[102,103],low=[101,102],high=[103,104],timestamps=['2026-10-26T12:00:00','2026-10-26T12:03:00']))
  self.assertTrue(any(k=='create_polygon' for k,a,v in c.calls));self.assertTrue(any(v.get('text')=='FORECAST' for k,a,v in c.calls))
  self.assertTrue(any('NOT confidence' in v.get('text','') for k,a,v in c.calls))
 def test_missing_prediction_no_fake_path(self):
  c=Canvas();draw_forecast(c,[],None);self.assertFalse(any(k=='create_polygon' for k,a,v in c.calls))

if __name__=='__main__':unittest.main()
