import unittest,tempfile,json,threading
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from engine import IST
from strategy_rules import trap,evening,daily_context,rsi14
from market_safety import parse_ban,parse_delivery,event_gate,SafetyReports
from option_research import choose_atm,premium_plan
from data import Dhan,DataError,Cache,parse_master
from news_alerts import important

NOW=pd.Timestamp('2026-10-30 10:00',tz=IST)

def minute_bar(start,o,h,l,c,v=1000,n=15):
 return pd.DataFrame(dict(open=o,high=h,low=l,close=c,volume=v),index=pd.date_range(start,periods=n,freq='min')).astype(float)
def trap_frame(mirror=False):
 prev=minute_bar(NOW.normalize()-pd.Timedelta(days=1)+pd.Timedelta(hours=9,minutes=15),105,108,102,105,n=375)
 start=NOW.normalize()+pd.Timedelta(hours=9,minutes=15)
 f=pd.concat([prev,minute_bar(start,100,100,95,97),minute_bar(start+pd.Timedelta(minutes=15),97,99,96,98,2000),minute_bar(start+pd.Timedelta(minutes=30),98,101,97,100.5,3000)])
 if mirror:
  old=f.copy()
  for c in ('open','close'):f[c]=200-old[c]
  f.high=200-old.low;f.low=200-old.high
 return f

class TrapTests(unittest.TestCase):
 def test_bear_ce_and_structural_stop(self):
  r=trap(trap_frame(),NOW);self.assertTrue(r['eligible'],r);self.assertEqual(r['option_side'],'CE');self.assertEqual(r['underlying_sl'],96);self.assertGreaterEqual(r['underlying_t1']-r['underlying_entry'],r['underlying_entry']-r['underlying_sl'])
 def test_bull_pe_mirror(self):
  r=trap(trap_frame(True),NOW);self.assertTrue(r['eligible'],r);self.assertEqual(r['option_side'],'PE');self.assertEqual(r['underlying_sl'],104);self.assertLess(r['underlying_t2'],r['underlying_t1'])
 def test_strict_gap_wick_and_third(self):self.assertTrue(trap(trap_frame(),NOW,True)['matched'])
 def test_strict_rejects_wick_but_written_does_not(self):
  f=trap_frame();mask=(f.index>=NOW.normalize()+pd.Timedelta(hours=9,minutes=15))&(f.index<NOW.normalize()+pd.Timedelta(hours=9,minutes=30));f.loc[mask,'high']=100.2
  self.assertTrue(trap(f,NOW)['matched']);self.assertFalse(trap(f,NOW,True)['matched'])
 def test_future_candles_do_not_change_trigger(self):
  f=trap_frame();future=minute_bar(NOW,100,120,90,110);self.assertEqual(trap(f,NOW),trap(pd.concat([f,future]),NOW))
 def test_missing_opening_bar_blocks(self):self.assertFalse(trap(trap_frame().drop(NOW.normalize()+pd.Timedelta(hours=9,minutes=17)),NOW)['matched'])
 def test_late_trigger_historical(self):self.assertFalse(trap(trap_frame(),NOW+pd.Timedelta(minutes=20))['eligible'])
 def test_delayed_vwap_anchor(self):
  f=trap_frame().loc[lambda f:f.index.normalize()<NOW.normalize()];s=NOW.normalize()+pd.Timedelta(hours=9,minutes=15)
  f=pd.concat([f,minute_bar(s,110,110,95,99),minute_bar(s+pd.Timedelta(minutes=15),98,100,97,99.2),minute_bar(s+pd.Timedelta(minutes=30),99,104,98,103),minute_bar(s+pd.Timedelta(minutes=45),103,106,102,105.5)])
  self.assertTrue(trap(f,NOW+pd.Timedelta(minutes=15))['matched']);self.assertFalse(trap(f,NOW+pd.Timedelta(minutes=15),True)['matched'])
 def test_stop_on_close_not_wick(self):
  f=trap_frame();extra=minute_bar(NOW,100,102,94,100)
  r=trap(pd.concat([f,extra]),NOW+pd.Timedelta(minutes=15));self.assertNotIn('SL CLOSE',r['strategy_status'])

class SafetyTests(unittest.TestCase):
 def test_ban_parse(self):self.assertEqual(parse_ban('SYMBOL\nABC\n','2026-10-30')['symbols'],['ABC'])
 def test_ban_html_rejected(self):
  with self.assertRaises(ValueError):parse_ban('<html>error</html>','2026-10-30')
 def test_delivery_date_and_percent(self):
  r=parse_delivery('SYMBOL,SERIES,DATE1,DELIV_PER\nABC,EQ,29-Oct-2026,45.5\n','2026-10-29');self.assertEqual(r['values']['ABC'],45.5)
  with self.assertRaises(ValueError):parse_delivery('SYMBOL,SERIES,DATE1,DELIV_PER\nABC,EQ,29-Oct-2026,45.5\n','2026-10-30')
 def calendar(self):return dict(reviewed_by='test',sources=['official source'],reviewed_at=NOW.isoformat(),coverage_start=(NOW-pd.Timedelta(hours=1)).isoformat(),coverage_end=(NOW+pd.Timedelta(days=11)).isoformat(),events=[])
 def test_calendar_unknown_not_clear(self):self.assertIn('UNKNOWN',event_gate({},'ABC',NOW))
 def test_event_blocks_btst(self):
  c=self.calendar();c['events']=[dict(at=(NOW+pd.Timedelta(days=1)).isoformat(),title='RBI decision',symbol='ALL',impact='HIGH',source='https://rbi.org.in')];self.assertIn('EVENT BLOCK',event_gate(c,'ABC',NOW))
 def test_calendar_review_expires(self):self.assertIn('UNKNOWN',event_gate(self.calendar(),'ABC',NOW+pd.Timedelta(days=2)))
 def test_delivery_proxy_explicit(self):
  with tempfile.TemporaryDirectory() as root:
   service=SafetyReports(root,threading.Event());(service.root/'risk_calendar.json').write_text(json.dumps(self.calendar()))
   def read(kind,day):return {'symbols':[],'date':day} if kind=='ban' else {'values':{'ABC':60},'date':day} if day=='2026-10-29' else None
   service._read=read
   self.assertEqual(service.gates('ABC',NOW,True,'2026-10-29')['delivery_check'],'UNKNOWN')
   self.assertEqual(service.gates('ABC',NOW,True,'2026-10-29',True)['delivery_check'],'PASS PRIOR-SESSION PROXY')

class OptionTests(unittest.TestCase):
 def setUp(self):
  self.c=dict(id='123',expiry='2026-11-24',side='CE',strike=100.,lot=100)
  self.leg=dict(security_id=123,greeks=dict(delta=.5,gamma=.001))
  self.chain={'data':{'last_price':101,'oc':{'100':{'ce':self.leg},'105':{'ce':dict(security_id=999)}}}}
  self.q=dict(last_trade_time=NOW.isoformat(),volume=1000,depth={'buy':[{'price':9.9}],'sell':[{'price':10.}]})
  self.r=dict(underlying_now=101,underlying_sl=99,underlying_t1=104,underlying_t2=107)
 def test_atm_security_and_lot_match(self):self.assertEqual(choose_atm(self.chain,[self.c],self.c['expiry'],'CE',NOW)[0]['id'],'123')
 def test_no_contract_substitution(self):
  with self.assertRaises(ValueError):choose_atm(self.chain,[],self.c['expiry'],'CE',NOW)
 def test_ordered_premium_estimates_and_one_lot(self):
  r=premium_plan(self.r,self.c,self.leg,self.q,NOW);self.assertEqual(r['quantity'],100);self.assertLess(r['premium_sl_est'],r['premium_entry']);self.assertLess(r['premium_entry'],r['premium_t1_est'])
 def test_risk_budget_rejects_does_not_tighten_stop(self):
  a=premium_plan(self.r,self.c,self.leg,self.q,NOW,budget=5);b=premium_plan(self.r,self.c,self.leg,self.q,NOW);self.assertEqual(a['quantity'],0);self.assertEqual(a['premium_sl_est'],b['premium_sl_est'])
 def test_stale_option_quote_rejected(self):
  with self.assertRaises(ValueError):premium_plan(self.r,self.c,self.leg,self.q,NOW+pd.Timedelta(minutes=3))
 def test_missing_greeks_rejected(self):
  with self.assertRaises(ValueError):premium_plan(self.r,self.c,{},self.q,NOW)

class EveningTests(unittest.TestCase):
 def setUp(self):
  self.now=NOW.normalize()+pd.Timedelta(hours=15,minutes=15);idx=pd.bdate_range(end=NOW.normalize()-pd.Timedelta(days=1),periods=140)
  c=100+np.sin(np.arange(140))*.5
  self.daily=pd.DataFrame(dict(open=c-.05,high=c+.1,low=c-.1,close=c,volume=10000.),index=idx)
  self.f=minute_bar(NOW.normalize()+pd.Timedelta(hours=9,minutes=15),101,101.1,100.9,101,100,n=375)
 def test_125_day_positive(self):
  r=evening(self.daily,self.f,self.now)[0];self.assertTrue(r['matched'],r);self.assertTrue(r['eligible']);self.assertLess(r['underlying_sl'],r['underlying_entry'])
 def test_125_excludes_current_from_high(self):
  r=evening(self.daily,self.f,self.now)[0];self.assertAlmostEqual(r['breakout_level'],self.daily.high.tail(125).max())
 def test_short_history_rejected(self):self.assertIn('125',evening(self.daily.tail(100),self.f,self.now)[0]['reason'])
 def test_scan_time_gating(self):self.assertFalse(evening(self.daily,self.f,NOW)[0]['matched'])
 def test_daily_partial_lookahead_prevention(self):
  a=evening(self.daily,self.f,self.now);f=self.f.copy();f.loc[f.index>=self.now,['open','high','low','close']]*=2
  self.assertEqual(a,evening(self.daily,f,self.now))
 def test_no_omitted_minutes(self):
  with self.assertRaises(ValueError):daily_context(self.daily,self.f.drop(self.f.index[3]),self.now)
 def test_btst_time_and_rsi(self):
  r=evening(self.daily,self.f,NOW.normalize()+pd.Timedelta(hours=15,minutes=5))[1];self.assertFalse(r['eligible']);self.assertTrue(r['reason'])

class IntegrationContracts(unittest.TestCase):
 def test_read_only_allowlist_still_blocks_order(self):
  with self.assertRaises(DataError):Dhan('x','x',threading.Event()).request('/orders',{})
 def test_daily_cache_preserves_midnight_rows(self):
  with tempfile.TemporaryDirectory() as root:
   c=Cache(root);f=pd.DataFrame(dict(open=[1.],high=[2.],low=[1.],close=[2.],volume=[10.]),index=pd.DatetimeIndex([NOW.normalize()]))
   c.save_daily('A',f);self.assertEqual(c.load_daily('A').index[0],NOW.normalize());c.close()
 def test_news_events_and_future_filter(self):
  items=[dict(publishDate=NOW.isoformat(),newsObject=dict(title='RBI repo rate decision',text='Report')),dict(publishDate=(NOW+pd.Timedelta(days=1)).isoformat(),newsObject=dict(title='Quarterly earnings',text='Future'))]
  rows=important(items,NOW);self.assertEqual(len(rows),1);self.assertIn('rates',rows[0]['tags'])
if __name__=='__main__':unittest.main()
